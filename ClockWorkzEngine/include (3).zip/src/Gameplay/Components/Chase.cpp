// Gameplay/Components/Chase.cpp
#include "Gameplay/Components/Chase.hpp"
#include "Gameplay/GameObject.hpp"
#include "Math/Vec2.hpp"


namespace Gameplay {

    // Try to find target once (or when invalid). Adjust to your engine's API.
    GameObject* ChaseComponent::resolveTarget(GameObject& owner) {
        if (m_target) return m_target;
        auto* s = owner.scene();                   // <� your scene
        if (!s) return nullptr;
        if (!m_hint.name.empty())
            if (auto* f = s->findByName(m_hint.name))       return m_target = f;
        if (m_hint.layer >= 0)
            if (auto* f = s->findFirstByLayer(m_hint.layer)) return m_target = f;
        return nullptr;
    }

    // Get target velocity; if you don't have getVelocity(), estimate it.
    // Prefer a real getter if available.
    vec2 ChaseComponent::getVelocity(GameObject& obj) {
        if (obj.velocity()) {                // replace with your actual API
            return obj.velocity();
        }
        // Velocityless object: estimate using a tiny cache (optional)
        // For simplicity, return zero here:
        return { 0.f, 0.f };
    }

} // namespace Gameplay