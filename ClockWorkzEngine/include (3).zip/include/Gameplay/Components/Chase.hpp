// Gameplay/Components/Chase.hpp
#pragma once
#include "Gameplay/GameObject.hpp"
#include "Math/Vec2.hpp"
#include "Math/config.hpp"         
#include <string>
#include <cfloat>

namespace Gameplay {

    class ChaseComponent : public Component {
    public:
        struct TargetHint {
            std::string name;    // optional: resolve by object name/tag
            int         layer{ -1 }; // optional: resolve by layer (e.g., Layer::Player)
        };

        ChaseComponent(float speed = 140.f,
            float arriveRadius = 12.f,
            bool predictive = true,
            float maxPredictTime = 0.5f,
            TargetHint hint = {})
            : m_speed(speed), m_arriveRadius(arriveRadius),
            m_predict(predictive), m_maxPredict(maxPredictTime),
            m_hint(std::move(hint)) {
        }

        // Runtime control
        void setSpeed(float s) { m_speed = s < 0.f ? 0.f : s; }
        void setArriveRadius(float r) { m_arriveRadius = r < 0.f ? 0.f : r; }
        void setPredictive(bool on) { m_predict = on; }
        void setMaxPredict(float t) { m_maxPredict = t < 0.f ? 0.f : t; }

        void setTarget(GameObject* target) { m_target = target; }
        void setTargetByName(std::string n) { m_hint.name = std::move(n); m_target = nullptr; }
        void setTargetByLayer(int layer) { m_hint.layer = layer; m_target = nullptr; }

        // Hooks
        void onBeforePhysics(GameObject& owner, double dt) override {
            tick(owner, dt);
        }
        void onUpdate(GameObject& owner, double dt) override {
            // Fallback if your engine only calls onUpdate post-physics:
            if (!m_usedThisFrame) tick(owner, dt);
            m_usedThisFrame = false;
        }

    private:
        void tick(GameObject& owner, double dt) {
            m_usedThisFrame = true;
            if (m_speed <= 0.f) { owner.setVelocity({ 0,0 }); return; }

            GameObject* tgt = resolveTarget(owner);
            if (!tgt) { owner.setVelocity({ 0,0 }); return; }

            vec2 p = owner.transform().position;
            vec2 tp = tgt->transform().position;

            // Arrival: stop within radius
            vec2 toT = tp - p;
            float dist = magnitude(toT);
            if (dist <= m_arriveRadius) { owner.setVelocity({ 0,0 }); return; }

            // Predictive lead (optional)
            if (m_predict) {
                vec2 tv = getVelocity(*tgt);
                float tvSpeed = magnitude(tv);
                if (tvSpeed > 1e-4f) {
                    // time to intercept (simple linear prediction)
                    float t = dist / (m_speed + tvSpeed);
                    if (t > m_maxPredict) t = m_maxPredict;
                    tp = tp + tv * t;
                    toT = tp - p;
                    dist = magnitude(toT);
                }
            }

            // Desired velocity
            vec2 dir = dist > 1e-4f ? (toT / dist) : vec2{ 0,0 };
            owner.setVelocity(dir * m_speed);
        }

        GameObject* resolveTarget(GameObject& owner);
        vec2 getVelocity(GameObject& obj);

        // Tunables
        float m_speed{ 140.f };
        float m_arriveRadius{ 12.f };
        bool  m_predict{ true };
        float m_maxPredict{ 0.5f };

        // Target
        GameObject* m_target{ nullptr };
        TargetHint    m_hint{};
        bool          m_usedThisFrame{ false };
    };

} // namespace Gameplay