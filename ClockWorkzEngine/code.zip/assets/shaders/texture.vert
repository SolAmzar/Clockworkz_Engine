#version 330 core
layout (location = 0) in vec3 aPos;      // vertex position (x, y, z)
layout (location = 1) in vec2 aTexCoord; // texture coordinates

out vec2 TexCoord;

uniform mat4 projection;
uniform mat4 model;

void main()
{
    gl_Position = projection * model * vec4(aPos, 1.0);
    TexCoord = aTexCoord;
}
