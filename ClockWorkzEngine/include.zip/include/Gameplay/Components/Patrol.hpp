/******************************************************************************/
/*!
\file           Health.hpp
\project        Lights Out
\author(s)      [Amzar], 100%
\brief          Declares PatrolComponent, a component of a GameObject that makes it
                patrol between two points A and B at a specified speed.
                Responsibilities include:
                - Moving the GameObject back and forth between points A and B
                - Updating the GameObject's velocity each frame to achieve patrol behavior
				Used to create patrolling enemies or moving platforms in the game.
             

All content ? 2025 DigiPen Institute of Technology Singapore. All rights reserved.
*/
/******************************************************************************/

#pragma once
#include "Gameplay/GameObject.hpp"

namespace Gameplay {
    class PatrolComponent : public Component {
    public:
        PatrolComponent(vec2 a, vec2 b, float speed) : m_a(a), m_b(b), m_speed(speed) {}

        void onUpdate(GameObject& owner, double dt) override {
            // pick current target
            vec2 target = m_forward ? m_b : m_a;
            vec2 p = owner.transform().position;
            vec2 d = target - p;
            float dist2 = dot(d, d);
            if (dist2 < 1.0f) { // arrived -> flip
                m_forward = !m_forward;
                return;
            }
            float len = std::max(std::sqrt(dist2), 1e-6f);
            vec2 dir = (1.0f / len) * d;
            owner.velocity() = dir * m_speed; // engine already integrates velocity in update()
        }

        // getters
        vec2 a() const { return m_a; }
        vec2 b() const { return m_b; }
        float speed() const { return m_speed; }

    private:
        vec2  m_a{}, m_b{};
        float m_speed{ 100.f };
        bool  m_forward{ true };
    };
}
